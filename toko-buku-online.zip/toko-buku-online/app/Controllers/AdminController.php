<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }

    public function createBuku(){
        $data = $this->request->getpost();
        $file = $this->request->getFile('cover');

        if (!$file->hasMoved()){
            $path = $file->store();
            $data['cover'] = $path;
        }

        $bukuModel = model('BookModel');

        if($bukuModel->insert($data, false)){
            return redirect()->to('admin/daftar-buku')->with('sukses','Data Berhasil Disimpan');
        }else {
            return redirect('admin/daftar-buku')->with('error','Data Gagal Disimpan!');
        }
    }
    public function daftarBuku(){
        $modelBuku = model('BookModel');
        $data['books'] = $modelBuku->findAll();
        dd($data['books']);

        return view('admin/daftar-buku', $data);
    }
    public function daftarBukuTambah(){
        return view('admin/daftar-buku-tambah');
    }
    public function daftarBukuEdit($id){
        $modelBuku = new \App\Models\BookModel();
        $buku = $modelBuku->find($id);

        if (!$buku) {
        return redirect()->to('admin/daftar-buku')->with('error', 'Buku tidak ditemukan.');
    }
        return view('admin/daftar-buku-edit', ['buku' => $buku]);
    }

    public function updateBuku($id)
    {
    $modelBuku = new \App\Models\BookModel();
    $buku = $modelBuku->find($id);

    if (!$buku) {
        return redirect()->to('admin/daftar-buku')->with('error', 'Buku tidak ditemukan.');
    }

    $data = $this->request->getPost();

    $file = $this->request->getFile('cover');
    if ($file && $file->isValid() && !$file->hasMoved()) {
        if (!empty($buku['cover'])) {
            $filePath = WRITEPATH . 'uploads/' . $buku['cover'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        $data['cover'] = $file->store();
    }

    if ($modelBuku->update($id, $data)) {
        return redirect()->to('admin/daftar-buku')->with('success', 'Buku berhasil diperbarui.');
    }

    return redirect()->to('admin/daftar-buku')->with('error', 'Buku gagal diperbarui.');
    }

    public function daftarBukuHapus($id){
        
    $modelBuku = new \App\Models\BookModel();
    $buku = $modelBuku->find($id);

    if (!$buku) {
        return redirect()->to('admin/daftar-buku')->with('error', 'Buku tidak ditemukan.');
    }
    return view('admin/daftar-buku-hapus', ['buku' => $buku]);
    }

    public function hapusProses($id)
    {
    $bukuModel = new \App\Models\BookModel();
    
    $buku = $bukuModel->find($id);

    if (!$buku) {
        return redirect()->to('admin/daftar-buku')->with('error', 'Buku tidak ditemukan.');
    }

    if ($buku['cover']) {
        $filePath = WRITEPATH . 'uploads/' . $buku['cover'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    $bukuModel->delete($id);

    return redirect()->to('admin/daftar-buku')->with('success', 'Buku berhasil dihapus.');
    }

    public function transaksi(){
        $modelTransaksi = new \App\Models\TransaksiModel(); // Pastikan model ini sudah ada
        $data['transaksi'] = $modelTransaksi->findAll(); // Ambil semua data transaksi

    return view('admin/transaksi', $data);
    }
    public function transaksiUbahStatus(){
        return view('admin/transaksi-ubah-status');
    }
    public function transaksiHapus(){
        return view('admin/transaksi-hapus');
    }

    public function pelanggan(){
        $modelPelanggan = new \App\Models\PelangganModel();
    $data['pelanggan'] = $modelPelanggan->findAll();

    return view('admin/pelanggan', $data);
    }

    public function pelangganTambah()
    {
    return view('admin/pelanggan-tambah');
    }
    public function prosesTambahPelanggan()
    {
    $validation = \Config\Services::validation();

    // Validasi input
    if (!$this->validate([
        'nama' => 'required|min_length[3]',
        'telepon' => 'required|regex_match[/^[0-9]{10,15}$/]',
        'alamat' => 'required|min_length[5]'
    ])) {
        return redirect()->to('admin/pelanggan/tambah')->withInput()->with('errors', $validation->getErrors());
    }

    // Ambil data input
    $data = [
        'nama' => $this->request->getPost('nama'),
        'telepon' => $this->request->getPost('telepon'),
        'alamat' => $this->request->getPost('alamat')
    ];

    $modelPelanggan = new \App\Models\PelangganModel();

    // Simpan data pelanggan
    if ($modelPelanggan->save($data)) {
        return redirect()->to('admin/pelanggan')->with('success', 'Pelanggan berhasil ditambahkan.');
    } else {
        return redirect()->to('admin/pelanggan/tambah')->with('error', 'Gagal menambahkan pelanggan.');
    }
    }

    public function pelangganHapus($id){
        $modelPelanggan = new \App\Models\PelangganModel();
    
    // Cek apakah pelanggan ada
    $pelanggan = $modelPelanggan->find($id);
    
    if (!$pelanggan) {
        return redirect()->to('admin/pelanggan')->with('error', 'Pelanggan tidak ditemukan.');
    }
    
    // Hapus data pelanggan
    $modelPelanggan->delete($id);
    
    return redirect()->to('admin/pelanggan')->with('success', 'Pelanggan berhasil dihapus.');
}
}